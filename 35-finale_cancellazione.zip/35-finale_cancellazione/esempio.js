var config=require('./config')
var readline=require('readline')
var input=readline.createInterface(process.stdin, process.stdout)
var conn=null

voci_menu=[
	'Nuova voce',
	'Ricerca',
	'Cancella',
	'Fine'
]

function nuovaVoce(cognome, nome, numero){
	q=`INSERT INTO rubrica (cognome, nome, numero) \
	VALUES \
	('${cognome}', '${nome}', '${numero}')`
	
	conn.query(q, 
	(err, results, fields) =>{
		chiusura()
	})
}

function menu_inserimento(){
	console.log("==> Inserimento contatto: cognome;nome;telefono")
	input.question('Contatto: ',
		contatto => {
			parti=contatto.split(';')
			if (parti.length>=3)
				nuovaVoce(parti[0].trim(),parti[1].trim(),parti[2].trim())
			else{
				console.log("ERRORE: Formato in input non corretto")
				chiusura()
			}
		})
}

function query(ricerca){
	conn.query(`SELECT * FROM rubrica WHERE concat_ws(' ',cognome,nome) \
	LIKE '%${ricerca}%'`,
	(err, results, fields)=>{
		if (!err){
			if (results.length<1)
				console.log(`Nessuna voce individuata`)
			else
				for (r of results)
					console.log(`${r.id} ${r.cognome} ${r.nome} ${r.numero}`)
		}
		chiusura()
	})
	
}

function menu_ricerca(){
	input.question('\nImmettere la stringa da cercare:', 
		stringa => query(stringa)
	)
}

function cancellaVoce(id){
	q=`DELETE FROM rubrica WHERE id=${id}`
	conn.query(q,
	(err, results, fields)=>{
	  if (!err){
		if (results.affectedRows>0)  
		  console.log('Cancellazione eseguita')
	    else
		  console.log('Niente da cancellare')
	  }
	  chiusura()
	})
}

function cancellazioneId(id){
	conn.query(`SELECT * FROM rubrica WHERE id=${id}`,
	(err,results,fields)=>{
	  if (!err){
		  if (results.length>0){
			da_cancellare=results[0]
		    console.log(`Sarà cancellato ${da_cancellare.id} ${da_cancellare.cognome} \
			${da_cancellare.nome}`)
			input.question('Confermi (y/N)? ',
			 (risposta)=>{
				if (risposta.trim()=='y'){
					cancellaVoce(id)
					console.log('Cancellazione confermata')
				} 
				else {
					console.log('Operazione NON confermata')
				    chiusura()}
			 })  
		  }
		  else {
			  console.log(`Id ${id} non presente in rubrica`)
		      chiusura()}
	  }
	})
}

function menu_cancella(){
	input.question('\nId: ',
		id => cancellazioneId(id)
	)
}

function attivazione(func){
	conn=my.createConnection(credenziali)
	conn.connect(
		(err) => {
			if (!err)
				func()
			else
			{
				console.log('Errore di connessione al database')
				process.exit(1)
			}
		})
}

function chiusura(){
	conn.end((err) => {
		avvio()
	})
}

function elaboraRispostaMenu(risposta){
	switch(risposta){
		
		case '1':
			attivazione(menu_inserimento)
			break
		case '2':
			attivazione(menu_ricerca)
			break
		case '3':
			attivazione(menu_cancella)
			break
		case '4':
			console.log('\nFine esecuzione')
			process.exit()
		default:
			console.log('\nVoce inesistente')
			avvio()
	}
}

function avvio(){
	ind=1
	console.log('\n\nOpzioni rubrica')
	
	voci_menu.forEach(
		voce => console.log(`${ind++} - ${voce}`)
	)
	
	input.question('Scelta: ', elaboraRispostaMenu)
}

avvio()







