my=require('mysql')

credenziali={
	host: 'localhost',
	user: 'dbuser',
	password: 'topolino',
	database: 'sistema_chat'
}

conn=my.createConnection(credenziali)


function query(){
	conn.query('SELECT c.cognome,c.nome, count(testo) as quanti FROM contatti c \
	LEFT JOIN messaggi m ON c.id=m.id_mittente \
	GROUP BY c.id \
	ORDER BY quanti DESC',
	(err,results,fields)=>{
	  no_messaggi=''
	  if (err){
		  console.log('Errore nella query!')
	  }	
	  else
	  {
		  for (r of results)
			  if (r.quanti>0)
				  console.log(`${r.cognome} ${r.nome} ha scritto ${r.quanti} messaggi`)
			  else
				  no_messaggi+=`- ${r.cognome} ${r.nome}\n`
			  
		  if (no_messaggi.length>0)
			  console.log(`\nNon hanno scritto messaggi:\n${no_messaggi}`)
	  }
		
	})
}


conn.connect(
(err) =>{
	if (err)
		console.log('Errore!')
	else
	{
		console.log('Connessione OK!')
		query()
		chiusura()
	}
})

function chiusura(){
	conn.end((err)=>{
		if (err)
			console.log('Errore in chiusura!')
		else
			console.log('Chiusura connessione OK!')
		
	})
}







