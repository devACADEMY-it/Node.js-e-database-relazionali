var readline=require('readline')
var input=readline.createInterface(process.stdin, process.stdout)

voci_menu=[
	'Nuova voce',
	'Ricerca',
	'Cancella',
	'Fine'
]

function elaboraRispostaMenu(risposta){
	switch(risposta){
		
		case '1':
			console.log('\nNuovo inserimento')
			break
		case '2':
			console.log('\nRicerca di voci nella rubrica')
			break
		case '3':
			console.log('\nCancellazione di una voce')
			break
		case '4':
			console.log('\nFine esecuzione')
			process.exit()
		default:
			console.log('\nVoce inesistente')
	}
	avvio()
}

function avvio(){
	ind=1
	console.log('\n\nOpzioni rubrica')
	
	voci_menu.forEach(
		voce => console.log(`${ind++} - ${voce}`)
	)
	
	input.question('Scelta: ', elaboraRispostaMenu)
}

avvio()







