my=require('mysql')

credenziali={
	host: 'localhost',
	user: 'dbuser',
	password: 'topolino',
	database: 'sistema_chat'
}

conn=my.createConnection(credenziali)


function query(){
	conn.query(
		"CREATE TABLE IF NOT EXISTS contatti_non_attivi LIKE contatti",
		(err, results, fields) =>{
			if (!err)
				conn.query(
		           "TRUNCATE TABLE contatti_non_attivi",
		            (err, results, fields) =>{
						if (!err)
							spostamentoContatti()
						else
							console.log("Troncamento tabella non riuscito")
				})
			else
				console.log("Errore nella creazione tabella destinazione")
		})
}

function spostamentoContatti(){
	conn.beginTransaction(
	  (err) =>{
		if (err)
			throw err
		q="INSERT INTO contatti_non_attivi \
		   SELECT * FROM contatti WHERE attivo='N'"
		conn.query(q, (err,results,fields)=>{
			if (err)
				return conn.rollback(()=>{
					console.log("Errore in INSERT")
					chiusura()
				})
			else{
				q="DELETE FROM contatti WHERE attivo='N'"
				return conn.query(q, (err,results,fields)=>{
					if (err)
					  return conn.rollback(()=>{
								console.log("Errore in DELETE")
								chiusura()
						})
					conn.commit((err)=>{
					  if (err)
					    return conn.rollback(()=>{
								console.log("Errore in COMMIT")
								chiusura()
						})
					  console.log("Transazione conclusa con SUCCESSO")
					  chiusura()
					})
				})
			}
		})
	  })
}

conn.connect(
(err) =>{
	if (err)
		console.log('Errore in CONNESSIONE!')
	else
		query()
})

function chiusura(){
	conn.end((err)=>{
		if (err)
			console.log('Errore in chiusura!')
		else
			console.log('Chiusura connessione OK!')
		
	})
}