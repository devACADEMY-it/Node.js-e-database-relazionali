my=require('mysql')

credenziali={
	host: 'localhost',
	user: 'dbuser',
	password: 'topolino'
}

conn=my.createConnection(credenziali)

function creazione_database(){
	conn.query('CREATE DATABASE IF NOT EXISTS sistema_chat',
	(err, results, fields)=>{
		if (err)
			console.log('Errore... '+err.sqlMessage)
		else
			console.log('Operazione su DB eseguita con successo!')
	})
}

conn.connect(
(err) =>{
	if (err)
		console.log('Errore!')
	else
	{
		console.log('Connessione OK!')
		creazione_database()
		chiusura()
	}
})

function chiusura(){
	conn.end((err)=>{
		if (err)
			console.log('Errore in chiusura!')
		else
			console.log('Chiusura connessione OK!')
		
	})
}







