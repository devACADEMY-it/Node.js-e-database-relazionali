my=require('mysql')

conn=my.createConnection(
{
	host: 'localhost',
	user: 'dbuser',
	password: 'topolino'
})

conn.connect(
(err) =>{
	if (err)
		console.log('Errore!')
	else
		console.log('Connessione OK!')
})