c=require('./config')
my=require('mysql')

conn=my.createConnection(c.credenziali)

conn.connect(
(err) =>{
	if (err)
		console.log('Errore!')
	else
		console.log('Connessione OK!')
})