credenziali = {
	host: 'localhost',
	user: 'dbuser',
	password: 'topolino'
}

exports.credenziali = credenziali