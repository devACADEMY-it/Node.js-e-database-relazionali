my=require('mysql')

credenziali={
	host: 'localhost',
	user: 'dbuser',
	password: 'topolino',
	database: 'sistema_chat'
}

conn=my.createConnection(credenziali)

function inserimento(idm,o,t,idd){
	q=`INSERT INTO messaggi \
	   (id_mittente, oggetto, testo, id_destinatario) \
	   VALUES \
	   (${idm}, '${o}','${t}', ${idd})`
	conn.query(q,
	(err,results,fields)=>{
		if (err)
			console.log('Errore sul database')
		else
			console.log('Righe inserite: '+results.affectedRows)
	})
}


conn.connect(
(err) =>{
	if (err)
		console.log('Errore!')
	else
	{
		console.log('Connessione OK!')
		inserimento(4,'Partita calcetto','Vieni?',8)
		chiusura()
	}
})

function chiusura(){
	conn.end((err)=>{
		if (err)
			console.log('Errore in chiusura!')
		else
			console.log('Chiusura connessione OK!')
		
	})
}







