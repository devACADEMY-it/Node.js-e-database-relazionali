my=require('mysql')

credenziali={
	host: 'localhost',
	user: 'dbuser',
	password: 'topolino',
	database: 'sistema_chat'
}

conn=my.createConnection(credenziali)

function modificaTabella(){
	query="ALTER TABLE contatti \
		   ADD attivo ENUM('Y','N') DEFAULT 'Y'"
	conn.query(query,
	(err, results, fields)=>{
			if (err)
				console.log('Errore')
			else
				console.log('Modifica eseguita!')
		
	})
}

function disattivaContatti(id_contatti){
	query="UPDATE contatti SET attivo='N' \
	       WHERE id in (?)"
	conn.query(query,[id_contatti],
	(err, results, fields)=>{
			if (err)
				console.log('Errore')
			else
				console.log('Righe modificate: '+results.affectedRows)
		
	})
}




conn.connect(
(err) =>{
	if (err)
		console.log('Errore!')
	else
	{
		console.log('Connessione OK!')
		modificaTabella()
		disattivaContatti([2,3,6,10])
		chiusura()
	}
})

function chiusura(){
	conn.end((err)=>{
		if (err)
			console.log('Errore in chiusura!')
		else
			console.log('Chiusura connessione OK!')
		
	})
}