my=require('mysql')

credenziali={
	host: 'localhost',
	user: 'dbuser',
	password: 'topolino',
	database: 'sistema_chat'
}

conn=my.createConnection(credenziali)

function query(){
	conn.query(
		'SELECT * FROM messaggi ORDER BY id_destinatario DESC LIMIT 1',
		(err,results,fields)=>{
		   if (err)
			   console.log('Errore sulla query')
		   else
			   console.log(results)
		})
}

conn.connect(
(err) =>{
	if (err)
		console.log('Errore!')
	else
	{
		console.log('Connessione OK!')
		query()
		chiusura()
	}
})

function chiusura(){
	conn.end((err)=>{
		if (err)
			console.log('Errore in chiusura!')
		else
			console.log('Chiusura connessione OK!')
		
	})
}







