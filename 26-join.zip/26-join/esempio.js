my=require('mysql')

credenziali={
	host: 'localhost',
	user: 'dbuser',
	password: 'topolino',
	database: 'sistema_chat'
}

conn=my.createConnection(credenziali)


function query(){
	conn.query(
		'SELECT cognome, nome, testo FROM contatti JOIN messaggi \
		ON contatti.id=id_mittente',
		(err, results, fields) =>{
			if (err)
				console.log('Errore nella query!')
			else
				for (r of results)
					console.log(`${r.cognome} ${r.nome} ha scritto "${r.testo}"`)
		})
}


conn.connect(
(err) =>{
	if (err)
		console.log('Errore!')
	else
	{
		console.log('Connessione OK!')
		query()
		chiusura()
	}
})

function chiusura(){
	conn.end((err)=>{
		if (err)
			console.log('Errore in chiusura!')
		else
			console.log('Chiusura connessione OK!')
		
	})
}







