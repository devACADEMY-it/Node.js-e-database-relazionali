my=require('mysql')
fs=require('fs')

credenziali={
	host: 'localhost',
	user: 'dbuser',
	password: 'topolino',
	database: 'sistema_chat'
}

conn=my.createConnection(credenziali)

function query(){
	conn.query('SELECT * FROM contatti ORDER BY cognome DESC',
	(err, results, fields)=>{
			if (err)
				console.log('Errore!')
			else{
				console.log('Query OK...')
				for (x of results){
					fs.appendFileSync('salvataggio.txt', 
					`${x.id};${x.cognome};${x.nome};${x.numero}\n`)
				}
			}
	})
	
}


conn.connect(
(err) =>{
	if (err)
		console.log('Errore!')
	else
	{
		console.log('Connessione OK!')
		query()
		chiusura()
	}
})

function chiusura(){
	conn.end((err)=>{
		if (err)
			console.log('Errore in chiusura!')
		else
			console.log('Chiusura connessione OK!')
		
	})
}