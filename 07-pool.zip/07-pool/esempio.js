my=require('mysql')

credenziali={
	connectionLimit: 5,
	host: 'localhost',
	user: 'dbuser',
	password: 'topolino'
}

pool = my.createPool(credenziali)

pool.getConnection(
(err, connection) =>{
	if (err)
		console.log('Errore sulla connessione!')
	else
	{
		console.log('Connessione attivata')
		console.log('Operazioni sul database...')
		connection.release()
		chiusura()
	}
	
})

function chiusura(){
	pool.end(
		(err) => {
			if (err)
				console.log('Errore in chiusura')
			else
				console.log('Chiusura corretta')
		}
	)}









