var config=require('./config')
var readline=require('readline')
var input=readline.createInterface(process.stdin, process.stdout)
var conn=null

voci_menu=[
	'Nuova voce',
	'Ricerca',
	'Cancella',
	'Fine'
]

function menu_inserimento(){
	console.log('\n**** Invocazione funzione menu_inserimento ****')
	chiusura()
}

function menu_ricerca(){
	console.log('\n**** Invocazione funzione menu_ricerca ****')
	chiusura()
}

function menu_cancella(){
	console.log('\n**** Invocazione funzione menu_cancella ****')
	chiusura()
}

function attivazione(func){
	conn=my.createConnection(credenziali)
	conn.connect(
		(err) => {
			if (!err)
				func()
			else
			{
				console.log('Errore di connessione al database')
				process.exit(1)
			}
		})
}

function chiusura(){
	conn.end((err) => {
		avvio()
	})
}

function elaboraRispostaMenu(risposta){
	switch(risposta){
		
		case '1':
			attivazione(menu_inserimento)
			break
		case '2':
			attivazione(menu_ricerca)
			break
		case '3':
			attivazione(menu_cancella)
			break
		case '4':
			console.log('\nFine esecuzione')
			process.exit()
		default:
			console.log('\nVoce inesistente')
			avvio()
	}
}

function avvio(){
	ind=1
	console.log('\n\nOpzioni rubrica')
	
	voci_menu.forEach(
		voce => console.log(`${ind++} - ${voce}`)
	)
	
	input.question('Scelta: ', elaboraRispostaMenu)
}

avvio()







