var readline=require('readline')
var input=readline.createInterface(process.stdin, process.stdout)

voci_menu=[
	'Nuova voce',
	'Ricerca',
	'Cancella',
	'Fine'
]

function avvio(){
	ind=1
	console.log('\n\nOpzioni rubrica')
	
	voci_menu.forEach(
		voce => console.log(`${ind++} - ${voce}`)
	)
	
	input.question('Scelta: ', (risposta) =>{
		console.log(`Hai risposto: ${risposta}`)
		avvio()
	})
}

avvio()







