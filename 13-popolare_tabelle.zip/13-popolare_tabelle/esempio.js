my=require('mysql')

cognomi=['Rossi','Bianchi','Gialli','Verdi','Neri','Arancioni']
nomi=['Gino','Alessio','Silvio','Noemi','Elena','Sara']
prefissi=['339','347','320','329']

credenziali={
	host: 'localhost',
	user: 'dbuser',
	password: 'topolino',
	database: 'sistema_chat'
}

conn=my.createConnection(credenziali)

function valoreRandom(dati){
	return dati[Math.floor(Math.random()*dati.length)]
}

function numeroRandom(){
	return Math.floor(Math.random()*500000)+500000
}

function creaTabella(){
	query="CREATE TABLE IF NOT EXISTS contatti( \
	id int(100) UNSIGNED NOT NULL AUTO_INCREMENT, \
	cognome varchar(50) NOT NULL, \
	nome varchar(50) NOT NULL, \
	numero varchar(50) NOT NULL, \
	PRIMARY KEY(id))"
	
	conn.query(query,
	(err,results,fields)=>{
		if (err)
			console.log('Errore in creazione tabella')
		else
			console.log('Tabella creata!')
	})
}

function generaDati(quanti){
	res=[]
	for(i=0;i<quanti;i++)
		res.push([valoreRandom(cognomi), 
					valoreRandom(nomi),
					 valoreRandom(prefissi)+numeroRandom()])
	return res
}

function inserimento(quanti){
	dati=generaDati(quanti)
	q='INSERT INTO contatti \
	   (cognome, nome, numero) \
	   VALUES ?'
	conn.query(q, [dati],
	 (err,results,fields)=>{
		if (err)
			console.log('Errore in inserimento')
		else
			console.log('Righe inserite: '+results.affectedRows)
	})
}


conn.connect(
(err) =>{
	if (err)
		console.log('Errore!')
	else
	{
		console.log('Connessione OK!')
		creaTabella()
		inserimento(12)
		chiusura()
	}
})

function chiusura(){
	conn.end((err)=>{
		if (err)
			console.log('Errore in chiusura!')
		else
			console.log('Chiusura connessione OK!')
		
	})
}