my=require('mysql')

credenziali={
	host: 'localhost',
	user: 'dbuser',
	password: 'topolino',
	database: 'sistema_chat'
}

conn=my.createConnection(credenziali)

function cancellaContatto(cognome, nome){
	q="DELETE FROM contatti \
	   WHERE cognome=? AND nome=?"
	
	conn.query(q, [cognome, nome],
	 (err,results,fields)=>{
		if (err)
		   console.log('Errore')
	    else if (results.affectedRows>0)
			console.log('Righe cancellate: '+results.affectedRows)
		     else
				 console.log('Niente da cancellare')
		 
	 })
}

conn.connect(
(err) =>{
	if (err)
		console.log('Errore!')
	else
	{
		console.log('Connessione OK!')
		cancellaContatto('Gialli','Gino')
		chiusura()
	}
})

function chiusura(){
	conn.end((err)=>{
		if (err)
			console.log('Errore in chiusura!')
		else
			console.log('Chiusura connessione OK!')
		
	})
}