my=require('mysql')

credenziali={
	host: 'localhost',
	user: 'dbuser',
	password: 'topolino',
	database: 'sistema_chat'
}

conn=my.createConnection(credenziali)

function query(){
	conn.query('SELECT * FROM messaggi',
	(err,results,fields)=>{
		if (err)
			console.log('Errore nella query!')
		else
			//console.log('Record recuperati: '+results.length)
			//console.log(results)
			console.log(results[4].oggetto)
	})
}

conn.connect(
(err) =>{
	if (err)
		console.log('Errore!')
	else
	{
		console.log('Connessione OK!')
		query()
		chiusura()
	}
})

function chiusura(){
	conn.end((err)=>{
		if (err)
			console.log('Errore in chiusura!')
		else
			console.log('Chiusura connessione OK!')
		
	})
}







