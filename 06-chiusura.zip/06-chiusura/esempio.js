my=require('mysql')

credenziali={
	host: 'localhost',
	user: 'dbuser',
	password: 'pippo'
}

conn=my.createConnection(credenziali)

conn.connect(
(err) =>{
	if (err)
		console.log('Errore!')
	else
	{
		console.log('Connessione OK!')
		console.log('Operazioni su DB in corso ...')
		chiusura()
	}
})

function chiusura(){
	conn.end((err)=>{
		if (err)
			console.log('Errore in chiusura!')
		else
			console.log('Chiusura connessione OK!')
		
	})
}







