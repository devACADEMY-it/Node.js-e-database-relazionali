my=require('mysql')

credenziali={
	host: 'localhost',
	user: 'dbuser',
	password: 'topolino',
	database: 'sistema_chat'
}

conn=my.createConnection(credenziali)

query="CREATE TABLE IF NOT EXISTS messaggi ( \
id int(10) UNSIGNED NOT NULL AUTO_INCREMENT, \
id_mittente int(10) UNSIGNED NOT NULL, \
oggetto varchar(50) NOT NULL, \
testo varchar(250) NOT NULL, \
id_destinatario int(10) UNSIGNED NOT NULL, \
PRIMARY KEY(id) ) \
ENGINE=MyISAM DEFAULT CHARSET=latin1"

function crea_tabella(){
	conn.query(query,
	(err, results, fields) =>{
			if (err)
				console.log('Errore nella creazione')
			else
				console.log('Operazione eseguita con successo')
	})
}

conn.connect(
(err) =>{
	if (err)
		console.log('Errore!')
	else
	{
		console.log('Connessione OK!')
		crea_tabella()
		chiusura()
	}
})

function chiusura(){
	conn.end((err)=>{
		if (err)
			console.log('Errore in chiusura!')
		else
			console.log('Chiusura connessione OK!')
		
	})
}







